// chrome.runtime.sendMessage({ action: 'logSite', site: window.location.hostname });

// timerLimit = new Date(2024, 4, 22, 0, )
// console.log(timerLimit.)


console.log("yo yo ")

document.addEventListener("DOMContentLoaded",()=>{
    setTimeout(()=>{
        alert("hello")
    },1)
})