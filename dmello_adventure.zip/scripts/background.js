// let websites = {};

// chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
//     if (changeInfo.status === 'complete') {
//         let hostname = new URL(tab.url).hostname;
//         if (!websites[hostname]) {
//             websites[hostname] = { timeSpent: 0 };
//         }
//     }
// });

// setInterval(() => {
//     chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
//         let activeTab = tabs[0];
//         let hostname = new URL(activeTab.url).hostname;
//         if (websites[hostname]) {
//             websites[hostname].timeSpent += 1;
//             // if (websites[hostname].timeSpent === 500) { // 30 minutes in seconds
//                 chrome.notifications.create({
//                     type: 'basic',
//                     iconUrl: 'icon.png',
//                     title: 'Reminder',
//                     message: 'You\'ve spent 30 minutes on this website.',
//                 });
//             }
//         }
//     });
// }, 1000); // Check every second